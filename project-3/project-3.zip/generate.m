clear;
clc;
close all;
%%%%%%%%%%%%%%%%%%%%%%%%
%Speaker signals
xx=gen();
W=makeplots(xx);


%%%%%%%%%%%%%%%%%%%%
%Images
%xx=imggen();
%W=makeimg(xx);





